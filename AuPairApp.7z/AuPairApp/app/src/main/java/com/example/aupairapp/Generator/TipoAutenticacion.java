package com.example.aupairapp.Generator;

public enum TipoAutenticacion {
    SIN_AUTENTICACION, BASIC, JWT, SIN_MASTER
}
